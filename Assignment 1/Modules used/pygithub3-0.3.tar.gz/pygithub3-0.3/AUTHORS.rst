python-github3 is written and maintained by **David Medina** and
various contributors:

Development Lead
=================

- David Medina <davidmedina9@gmail.com>

Forked and redesign from Kenneth Reitz's repo
----------------------------------------------

Forked from https://github.com/kennethreitz/python-github3

Kenneth Reitz is also the author of the awesome `requests <https://github.com/kennethreitz/requests>`_ library
which `python-github3` needs it

Patches and Suggestions
.........................

- Mahdi Yusuf
- Rok Garbas
- Antti Kaihola <akaihol+github@ambitone.com>
- Francisco Marcos <fmarcos83@gmail.com>
