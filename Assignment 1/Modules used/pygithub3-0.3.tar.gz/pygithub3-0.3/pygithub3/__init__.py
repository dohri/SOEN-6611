#!/usr/bin/env python
# -*- encoding: utf-8 -*-

__title__ = 'pygithub3'
__version__ = '0.3'
__author__ = 'David Medina'
__email__ = 'davidmedina9@gmail.com'
__license__ = 'ISC'
__copyright__ = 'Copyright 2012 David Medina'

from github import Github
